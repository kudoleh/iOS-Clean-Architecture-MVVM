//
//  Presentation.h
//  Presentation
//
//  Created by Oleh Kudinov on 11.08.19.
//  Copyright © 2019 Oleh Kudinov. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Presentation.
FOUNDATION_EXPORT double PresentationVersionNumber;

//! Project version string for Presentation.
FOUNDATION_EXPORT const unsigned char PresentationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Presentation/PublicHeader.h>


