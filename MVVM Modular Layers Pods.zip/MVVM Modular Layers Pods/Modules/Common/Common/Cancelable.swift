//
//  Cancellable.swift
//  ExampleMVVM
//
//  Created by Oleh Kudinov on 10.03.19.
//

import Foundation

public protocol Cancellable {
    func cancel()
}
