import XCTest
@testable import Common

final class CommonTests: XCTestCase {
    func testExample() throws {
    }
}
