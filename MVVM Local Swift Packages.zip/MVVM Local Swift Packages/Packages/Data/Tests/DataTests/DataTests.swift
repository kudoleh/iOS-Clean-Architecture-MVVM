import XCTest
@testable import Data

final class DataTests: XCTestCase {
    func testExample() throws {
    }
}
